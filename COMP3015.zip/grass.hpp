#pragma once
#include "object.hpp"

class GrassObject: Object {



};