#include "interface.hpp"


void Interface::Render() {
    ImGui::NewFrame();
    ImGui::Begin("test");
    ImGui::End();
}