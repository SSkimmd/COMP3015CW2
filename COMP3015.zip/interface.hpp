#pragma once
#include "imgui/imgui.h"

class Interface {
public:
	void Render();
private:
};