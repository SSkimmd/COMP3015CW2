#include "background.hpp"

void Background::Create(std::string file) {
    // For background

}

void Background::Render() {

}